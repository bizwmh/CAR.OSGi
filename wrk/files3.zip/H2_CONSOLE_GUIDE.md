# H2 Web Console Aktivierung - Alle Methoden

## 🚀 Methode 1: Schnellste Lösung - Gogo Console Command (SOFORT)

**In Ihrer laufenden Gogo Console:**

```bash
# H2 Console starten
osgi> new org.h2.tools.Server -webPort 8082 -webAllowOthers

# Oder mit allen Optionen:
osgi> exec java -cp bundles/04/h2-2.2.224.jar org.h2.tools.Server -web -webPort 8082
```

**Dann öffnen Sie im Browser:**
```
http://localhost:8082
```

**Connection Settings:**
```
JDBC URL:    jdbc:h2:./workspace/iam
Driver:      org.h2.Driver  
User:        sa
Password:    (leer lassen)
```

---

## 🎯 Methode 2: Programmatisch im Code (Empfohlen für Production)

### Variante A: In Ihrem bestehenden Bundle

Fügen Sie zu einem bestehenden Activator hinzu:

```java
import org.h2.tools.Server;

public class Activator implements BundleActivator {
    
    private Server h2Console;
    
    @Override
    public void start(BundleContext context) throws Exception {
        // Start H2 Web Console
        h2Console = Server.createWebServer(
            "-webPort", "8082",
            "-webAllowOthers"  // Für Remote-Zugriff
        );
        h2Console.start();
        
        System.out.println("H2 Console: " + h2Console.getURL());
    }
    
    @Override
    public void stop(BundleContext context) throws Exception {
        if (h2Console != null) {
            h2Console.stop();
        }
    }
}
```

### Variante B: Neues Declarative Service Bundle

Das habe ich für Sie vorbereitet:
- **H2ConsoleService.java** (mit Configuration Admin Support)
- **MANIFEST.MF**
- **pom.xml**

**Vorteile:**
✅ Konfigurierbar über Configuration Admin
✅ Automatischer Start/Stop
✅ Production-ready

---

## ⚡ Methode 3: Shell Script (für Development)

**h2-console.sh:**
```bash
#!/bin/bash
java -cp bundles/04/h2-2.2.224.jar org.h2.tools.Server \
  -web \
  -webPort 8082 \
  -webAllowOthers
```

**Windows (h2-console.bat):**
```batch
@echo off
java -cp bundles\04\h2-2.2.224.jar org.h2.tools.Server ^
  -web ^
  -webPort 8082 ^
  -webAllowOthers
```

---

## 🔧 Methode 4: Via framework.properties

**Fügen Sie zu framework.properties hinzu:**

```properties
# H2 Console Configuration
org.osgi.framework.bootdelegation=org.h2.tools.*

# Start H2 Console on framework startup (requires custom launcher code)
h2.console.enabled=true
h2.console.port=8082
h2.console.allowOthers=false
```

---

## 📊 Vergleich der Methoden

| Methode | Aufwand | Persistenz | Production | Flexibilität |
|---------|---------|------------|------------|--------------|
| Gogo Command | ⚡ Minimal | ❌ Nein | ❌ Nein | ⭐⭐ |
| Code im Activator | ⭐⭐ Gering | ✅ Ja | ⚠️ OK | ⭐⭐⭐ |
| DS Bundle | ⭐⭐⭐ Mittel | ✅ Ja | ✅ Ja | ⭐⭐⭐⭐⭐ |
| Shell Script | ⚡ Minimal | ❌ Nein | ❌ Nein | ⭐ |

---

## 🎯 Meine Empfehlung für Sie

### **Für SOFORT (Development):**
```bash
# In Gogo Console:
osgi> sh java -cp bundles/04/h2-2.2.224.jar org.h2.tools.Server -web -webPort 8082 -webAllowOthers
```

### **Für Production:**
Verwenden Sie das **H2ConsoleService Bundle**, das ich erstellt habe.

---

## 🔒 Sicherheits-Hinweise

### ⚠️ WICHTIG für Production:

```properties
# NIE in Production aktivieren:
h2.console.allowOthers=false  # ❌ Kein Remote-Zugriff

# Besser: Nur lokaler Zugriff
h2.console.enabled=true       # Nur auf localhost
h2.console.port=8082
```

### 🛡️ Sichere Konfiguration:

```java
Server.createWebServer(
    "-webPort", "8082",
    "-webAllowOthers", "false",  // Nur localhost
    "-webSSL"                    // SSL aktivieren
)
```

---

## 🌐 H2 Console Usage

### Nach dem Start:

1. **Browser öffnen:** http://localhost:8082

2. **Connection Settings eingeben:**
   ```
   Driver Class:  org.h2.Driver
   JDBC URL:      jdbc:h2:./workspace/iam
   User Name:     sa
   Password:      (leer)
   ```

3. **Verbinden** → Sie sehen Ihre Datenbank-Struktur

### Nützliche JDBC URLs:

```
# Embedded Mode (File-based)
jdbc:h2:./workspace/iam

# In-Memory (nur für Tests)
jdbc:h2:mem:testdb

# Server Mode (wenn H2 Server läuft)
jdbc:h2:tcp://localhost:9092/workspace/iam

# Mixed Mode (File + Server)
jdbc:h2:./workspace/iam;AUTO_SERVER=TRUE
```

---

## 🐛 Troubleshooting

### Problem: Port bereits belegt
```
Error: Port 8082 already in use
```

**Lösung:**
```bash
# Anderen Port verwenden
-webPort 8083
```

### Problem: Kein Remote-Zugriff
```
Connection refused from remote host
```

**Lösung:**
```bash
# Remote-Zugriff aktivieren
-webAllowOthers
```

### Problem: H2 Klasse nicht gefunden
```
ClassNotFoundException: org.h2.tools.Server
```

**Lösung:**
- Prüfen Sie, dass H2 Bundle (ID 13) **Active** ist
- Bundle-Status: `osgi> ss 13`

---

## 📦 Bundle Installation (wenn Sie DS Bundle verwenden)

```bash
# 1. Build
mvn clean package

# 2. Kopieren
cp target/car.osgi.h2.console-1.0.0.jar bundles/05/

# 3. Hot Deploy erkennt es automatisch, oder manuell:
osgi> install file:bundles/05/car.osgi.h2.console-1.0.0.jar
osgi> start <bundle-id>

# 4. Console URL erscheint in Logs:
[INFO] H2 Web Console started
[INFO] URL: http://localhost:8082
```

---

## 🎓 H2 Console Features

### Was Sie in der Console tun können:

1. **SQL Queries ausführen**
   ```sql
   SELECT * FROM USERS;
   INSERT INTO USERS VALUES (1, 'admin', 'password');
   ```

2. **Schema anzeigen**
   - Tables
   - Indexes
   - Sequences
   - Views

3. **Performance Monitoring**
   - Session info
   - Query statistics

4. **Database Management**
   - Backup
   - Export
   - Import

---

## 💡 Zusätzliche H2 Tools

### H2 bietet auch:

```java
// TCP Server (für Remote-Zugriff)
Server tcpServer = Server.createTcpServer(
    "-tcpPort", "9092",
    "-tcpAllowOthers"
);
tcpServer.start();

// PG Server (PostgreSQL Kompatibilität)
Server pgServer = Server.createPgServer(
    "-pgPort", "5435",
    "-pgAllowOthers"
);
pgServer.start();
```

---

## ✅ Quick Start Checklist

- [ ] H2 Bundle ist Active (Bundle 13)
- [ ] Methode gewählt (Gogo/Code/Bundle)
- [ ] Console gestartet
- [ ] Browser geöffnet (http://localhost:8082)
- [ ] JDBC URL eingegeben
- [ ] Verbindung erfolgreich
- [ ] 🎉 Ready to query!

---

**Welche Methode möchten Sie verwenden?**
