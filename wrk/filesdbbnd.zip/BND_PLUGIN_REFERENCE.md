# BND Maven Plugin - Quick Reference

## ✅ Vorteile gegenüber maven-bundle-plugin

1. **Moderner & Aktiv entwickelt**
   - Aktuellste OSGi R8 Standards
   - Regelmäßige Updates
   - Bessere Performance

2. **Sauberere Konfiguration**
   - Inline BND-Anweisungen in `<bnd>` Block
   - Keine `<instructions>` nötig
   - Bessere IDE-Integration

3. **Automatische DS-Generierung**
   - `-dsannotations: *` generiert automatisch SCR XMLs
   - Keine manuelle `Service-Component` Konfiguration

4. **Packaging bleibt `jar`**
   - Kein spezielles `bundle` packaging nötig
   - Standard Maven-Workflow

## 🔧 Hauptunterschiede

### maven-bundle-plugin (alt)
```xml
<packaging>bundle</packaging>  <!-- Spezielles packaging! -->

<plugin>
    <groupId>org.apache.felix</groupId>
    <artifactId>maven-bundle-plugin</artifactId>
    <version>5.1.9</version>
    <extensions>true</extensions>
    <configuration>
        <instructions>
            <Export-Package>com.example.api</Export-Package>
            <Import-Package>*</Import-Package>
            <Embed-Dependency>hikaricp</Embed-Dependency>
        </instructions>
    </configuration>
</plugin>
```

### bnd-maven-plugin (modern)
```xml
<packaging>jar</packaging>  <!-- Standard jar! -->

<plugin>
    <groupId>biz.aQute.bnd</groupId>
    <artifactId>bnd-maven-plugin</artifactId>
    <version>7.0.0</version>
    <executions>
        <execution>
            <goals>
                <goal>bnd-process</goal>
            </goals>
        </execution>
    </executions>
    <configuration>
        <bnd><![CDATA[
Export-Package: com.example.api
Import-Package: *
Private-Package: com.zaxxer.hikari.*
-dsannotations: *
        ]]></bnd>
    </configuration>
</plugin>
```

## 📝 BND-Anweisungen Cheat Sheet

### Wichtigste Direktiven

```properties
# Bundle Identity
Bundle-SymbolicName: biz.car.example
Bundle-Name: Example Bundle
Bundle-Version: 1.0.0

# Package Export (mit Version!)
Export-Package: \
    biz.car.api;version="1.0.0",\
    biz.car.util;version="1.0.0"

# Private Packages (nicht exportiert, aber im Bundle)
Private-Package: \
    biz.car.impl.*,\
    com.thirdparty.embedded.*

# Package Imports
Import-Package: \
    org.osgi.framework;version="[1.8,2)",\
    javax.sql,\
    *

# Declarative Services (automatische Generierung)
-dsannotations: *

# Capabilities
Provide-Capability: \
    osgi.service;objectClass="biz.car.api.MyService"
```

### Versions-Ranges

```properties
# Exact version
Import-Package: com.example;version="1.0.0"

# Range [min, max)
Import-Package: com.example;version="[1.0,2)"

# Minimum version
Import-Package: com.example;version="1.0.0"
```

### Optional Imports

```properties
# Resolution optional (Bundle läuft auch ohne)
Import-Package: \
    org.optional.package;resolution:=optional
```

### Embedding Dependencies

```properties
# Private-Package embedded automatisch
Private-Package: com.zaxxer.hikari.*

# Das inkludiert HikariCP-Klassen ins Bundle
```

## 🎯 Ihre Database Bundles

### car.database.api

**Key Points:**
- ✅ Exportiert `biz.car.database.api` mit Version
- ✅ Importiert nur `javax.sql`
- ✅ Kein DS (nur Interfaces)
- ✅ Packaging: `jar`

### car.database.h2

**Key Points:**
- ✅ Privat: `biz.car.database.h2.*` + HikariCP
- ✅ Importiert API mit Version Range `[1.0,2)`
- ✅ `-dsannotations: *` für @Component
- ✅ Packaging: `jar`
- ✅ HikariCP wird embedded

## 🚀 Build-Prozess

### 1. Clean Build
```bash
mvn clean install
```

### 2. Was passiert:
```
1. Java Compilation
2. BND Processing
   ├─ Analysiert Klassen
   ├─ Generiert MANIFEST.MF
   ├─ Generiert SCR XMLs (OSGI-INF/*.xml)
   └─ Embeddet Dependencies
3. JAR Creation
   └─ Mit generiertem MANIFEST.MF
```

### 3. Resultat:
```
target/
├── car.database.h2-1.0.0.jar
└── classes/
    ├── META-INF/
    │   └── MANIFEST.MF  ← Generiert von BND
    └── OSGI-INF/
        └── biz.car.database.h2.H2DataSourceService.xml  ← Auto-generiert
```

## 🔍 MANIFEST.MF Prüfen

```bash
# Nach dem Build:
cd target/classes
cat META-INF/MANIFEST.MF

# Oder im JAR:
unzip -p ../car.database.h2-1.0.0.jar META-INF/MANIFEST.MF
```

**Erwartetes MANIFEST (Auszug):**
```
Bundle-SymbolicName: biz.car.database.h2
Bundle-Version: 1.0.0
Import-Package: biz.car.database.api;version="[1.0,2)",
 javax.sql,org.h2;version="[2.2,3)",...
Private-Package: biz.car.database.h2,com.zaxxer.hikari
Service-Component: OSGI-INF/*.xml
```

## 🐛 Troubleshooting

### Problem: BND Plugin nicht gefunden
```
Could not resolve dependencies for project
```

**Lösung:**
```bash
# Maven Settings prüfen
cat ~/.m2/settings.xml

# Cache clearen
mvn dependency:purge-local-repository
```

### Problem: SCR XML nicht generiert
```
No Service-Component header in MANIFEST
```

**Lösung:**
```xml
<!-- Im pom.xml sicherstellen: -->
<bnd><![CDATA[
-dsannotations: *  ← Muss vorhanden sein!
]]></bnd>
```

### Problem: HikariCP nicht embedded
```
ClassNotFoundException: com.zaxxer.hikari.HikariDataSource
```

**Lösung:**
```xml
<bnd><![CDATA[
Private-Package: \
    biz.car.database.h2.*,\
    com.zaxxer.hikari.*  ← Muss explizit sein!
]]></bnd>
```

### Problem: Version Range Fehler
```
Missing Constraint: Import-Package: biz.car.database.api
```

**Lösung:**
- API Bundle muss zuerst installiert werden
- API Bundle muss Package mit Version exportieren:
  ```
  Export-Package: biz.car.database.api;version="1.0.0"
  ```

## ✅ Zusammenfassung

**bnd-maven-plugin ist besser weil:**
- ✅ Moderner & aktiv entwickelt
- ✅ Bessere OSGi R8 Unterstützung
- ✅ Automatische DS-Generierung
- ✅ Kein spezielles `bundle` packaging
- ✅ Sauberere Konfiguration

**Ihre POMs sind jetzt:**
- ✅ Mit bnd-maven-plugin 7.0.0
- ✅ Packaging: `jar` (Standard)
- ✅ Automatische `-dsannotations`
- ✅ Saubere Version-Ranges
- ✅ HikariCP embedded

**Ready to build!** 🚀
