# BND.BND Dateien - Best Practice Guide

## 🎯 Warum bnd.bnd Dateien verwenden?

### ✅ Vorteile:

1. **Separation of Concerns**
   - OSGi-Konfiguration getrennt von Maven
   - `bnd.bnd` ist OSGi-spezifisch
   - `pom.xml` bleibt sauber und fokussiert

2. **Wiederverwendbarkeit**
   - `bnd.bnd` kann mit anderen Build-Tools genutzt werden
   - Gradle, Ant, etc. können dieselbe Datei lesen

3. **Bessere IDE-Unterstützung**
   - Eclipse BND Tools
   - IntelliJ OSGi Plugin
   - Syntax-Highlighting für `.bnd` Dateien

4. **Versionierung & Wartung**
   - OSGi-Änderungen isoliert
   - Einfacher zu reviewen (Git diff)
   - Klare Struktur

## 📂 Projekt-Struktur

```
car.database.api/
├── src/
│   └── main/
│       └── java/
│           └── biz/car/database/api/
├── bnd.bnd          ← OSGi Manifest-Definitionen
└── pom.xml          ← Maven Build (sauber, minimal)

car.database.h2/
├── src/
│   └── main/
│       └── java/
│           └── biz/car/database/h2/
├── bnd.bnd          ← OSGi Manifest-Definitionen
└── pom.xml          ← Maven Build (sauber, minimal)
```

## 🔧 Wie bnd-maven-plugin bnd.bnd findet

### Automatische Suche (Standard):

```
1. ${project.basedir}/bnd.bnd          ← Erste Priorität
2. ${project.basedir}/src/bnd.bnd     ← Zweite Priorität
3. Inline <bnd> im pom.xml             ← Fallback
```

### Explizite Angabe (optional):

```xml
<plugin>
    <groupId>biz.aQute.bnd</groupId>
    <artifactId>bnd-maven-plugin</artifactId>
    <configuration>
        <bndfile>custom/path/to/bundle.bnd</bndfile>
    </configuration>
</plugin>
```

## 📝 bnd.bnd Syntax

### Kommentare

```properties
# Einzeiliger Kommentar

# Mehrzeilige Kommentare
# Zweite Zeile
# Dritte Zeile
```

### Mehrzeilige Werte (mit Backslash)

```properties
Export-Package: \
    biz.car.api;version="1.0.0",\
    biz.car.util;version="1.0.0"
```

### Variablen

```properties
# Definition
api.version: 1.0.0

# Verwendung
Export-Package: \
    biz.car.api;version="${api.version}"
```

### Makros

```properties
# BND Makro
Bundle-Version: ${Bundle-Version}
Bundle-Name: ${project.n}
```

## 🎨 Strukturierungs-Best Practices

### Empfohlene Struktur:

```properties
# ============================================================================
# 1. Bundle Identity (Wer bin ich?)
# ============================================================================
Bundle-SymbolicName: biz.car.example
Bundle-Name: Example Bundle
Bundle-Version: 1.0.0
Bundle-Description: Brief description
Bundle-Vendor: CAR

# ============================================================================
# 2. Package Exports (Was biete ich an?)
# ============================================================================
Export-Package: \
    biz.car.example.api;version="1.0.0"

# ============================================================================
# 3. Private Packages (Was behalte ich für mich?)
# ============================================================================
Private-Package: \
    biz.car.example.impl.*

# ============================================================================
# 4. Package Imports (Was brauche ich?)
# ============================================================================
Import-Package: \
    org.osgi.framework;version="[1.8,2)",\
    *

# ============================================================================
# 5. Service Components (Declarative Services)
# ============================================================================
-dsannotations: *

# ============================================================================
# 6. Capabilities (Was stelle ich bereit?)
# ============================================================================
Provide-Capability: \
    osgi.service;objectClass="biz.car.example.api.MyService"

# ============================================================================
# 7. Requirements
# ============================================================================
Bundle-RequiredExecutionEnvironment: JavaSE-17

# ============================================================================
# 8. Additional Metadata
# ============================================================================
Bundle-Category: Example
Bundle-License: Proprietary
Bundle-DocURL: https://example.com/docs
```

## 🔀 Vergleich: Inline vs. bnd.bnd

### Option A: Inline im pom.xml

```xml
<plugin>
    <groupId>biz.aQute.bnd</groupId>
    <artifactId>bnd-maven-plugin</artifactId>
    <configuration>
        <bnd><![CDATA[
Bundle-SymbolicName: biz.car.example
Export-Package: biz.car.example.api
Import-Package: *
        ]]></bnd>
    </configuration>
</plugin>
```

**Vorteile:**
- ✅ Alles in einer Datei
- ✅ Keine zusätzliche Datei

**Nachteile:**
- ❌ pom.xml wird groß
- ❌ Schlechte IDE-Unterstützung
- ❌ Schwer zu lesen (CDATA)

### Option B: Separate bnd.bnd Datei

**bnd.bnd:**
```properties
Bundle-SymbolicName: biz.car.example
Export-Package: biz.car.example.api
Import-Package: *
```

**pom.xml:**
```xml
<plugin>
    <groupId>biz.aQute.bnd</groupId>
    <artifactId>bnd-maven-plugin</artifactId>
    <!-- Keine <configuration> nötig! -->
</plugin>
```

**Vorteile:**
- ✅ Saubere Trennung
- ✅ pom.xml bleibt klein
- ✅ Bessere IDE-Unterstützung
- ✅ Einfacher zu warten

**Nachteile:**
- ⚠️ Eine zusätzliche Datei

## 🌟 Erweiterte Features

### 1. Conditional Packages

```properties
# Nur exportieren wenn vorhanden
-conditionalpackage: \
    com.thirdparty.optional.*
```

### 2. Baseline Check (API-Kompatibilität)

```properties
# Prüft ob neue Version API-kompatibel ist
-baseline: *
```

### 3. Contract Definitions

```properties
# Service Contract
-contract: \
    JavaServlet;version="4.0"
```

### 4. Build Path (für Compilation)

```properties
# Zusätzliche JARs für Compilation
-buildpath: \
    osgi.core;version=8.0.0,\
    osgi.cmpn;version=8.0.0
```

### 5. Test Configuration

```properties
# Test Dependencies
-testpath: \
    junit;version=4.13.2,\
    mockito-core;version=4.0.0
```

## 🔍 BND Macros & Variables

### System Properties

```properties
# Maven-Eigenschaften
Bundle-Version: ${project.version}
Bundle-Name: ${project.n}
```

### Built-in Macros

```properties
# Timestamp
Build-Date: ${tstamp}

# Git Info (wenn bnd-baseline-maven-plugin)
Git-SHA: ${Git-SHA}

# Java Version
Java-Version: ${java.version}
```

### Custom Variables

```properties
# Definition
company.name: CAR Technologies
api.version: 1.0.0

# Verwendung
Bundle-Vendor: ${company.name}
Export-Package: \
    biz.car.api;version="${api.version}"
```

## 📊 Komplettes Beispiel

### Realistisches car.database.h2/bnd.bnd

```properties
# ============================================================================
# Bundle Identity
# ============================================================================
Bundle-SymbolicName: biz.car.database.h2
Bundle-Name: CAR Database H2 Implementation
Bundle-Version: ${project.version}
Bundle-Description: ${project.description}
Bundle-Vendor: CAR Technologies
Bundle-Copyright: Copyright (c) 2026 CAR Technologies
Bundle-License: https://car.biz/license

# ============================================================================
# Package Configuration
# ============================================================================

# Private Packages (embedded in bundle)
Private-Package: \
    biz.car.database.h2.*,\
    com.zaxxer.hikari.*

# Package Imports with version ranges
Import-Package: \
    biz.car.database.api;version="[1.0,2)",\
    javax.sql,\
    javax.management,\
    org.h2.*;version="[2.2,3)",\
    org.osgi.framework;version="[1.8,2)",\
    org.osgi.service.component.annotations;version="[1.3,2)";resolution:=optional,\
    org.osgi.service.metatype.annotations;version="[1.4,2)";resolution:=optional,\
    org.osgi.service.cm;version="[1.6,2)",\
    org.slf4j;version="[2.0,3)",\
    *

# ============================================================================
# Declarative Services
# ============================================================================
-dsannotations: *
-dsannotations-options: version;minimum=1.3.0

# ============================================================================
# Metatype (Configuration)
# ============================================================================
-metatype: *

# ============================================================================
# Service Capabilities
# ============================================================================
Provide-Capability: \
    osgi.service;objectClass:List<String>="biz.car.database.api.DataSourceService";\
        effective:=active,\
    osgi.implementation;osgi.implementation="biz.car.database.h2";\
        version:Version="1.0.0"

# ============================================================================
# Requirements
# ============================================================================
Bundle-RequiredExecutionEnvironment: JavaSE-17

Require-Capability: \
    osgi.ee;filter:="(&(osgi.ee=JavaSE)(version>=17))",\
    osgi.extender;filter:="(&(osgi.extender=osgi.component)(version>=1.3))"

# ============================================================================
# Additional Metadata
# ============================================================================
Bundle-Category: Database,Persistence
Bundle-DocURL: https://car.biz/docs/database-h2
Bundle-Activator: (none)
Bundle-ActivationPolicy: lazy

# Build Information
Build-Jdk: ${java.version}
Build-Date: ${tstamp}
Built-By: ${user.name}

# ============================================================================
# Optional: Debugging
# ============================================================================
# -include: debug.bnd
```

## 🐛 Debugging bnd.bnd

### Verbose Output aktivieren

```xml
<plugin>
    <groupId>biz.aQute.bnd</groupId>
    <artifactId>bnd-maven-plugin</artifactId>
    <configuration>
        <bnd><![CDATA[
# Debugging aktivieren
-trace: true
-verbose: true
        ]]></bnd>
    </configuration>
</plugin>
```

### MANIFEST.MF prüfen

```bash
# Nach dem Build
cat target/classes/META-INF/MANIFEST.MF

# Formatiert anzeigen
bnd print target/car.database.h2-1.0.0.jar
```

### BND Validate

```bash
# Validate Bundle
bnd validate target/car.database.h2-1.0.0.jar
```

## ✅ Migration Checklist

### Von inline zu bnd.bnd:

- [ ] 1. Erstelle `bnd.bnd` im Projekt-Root
- [ ] 2. Kopiere `<bnd>` Inhalt aus pom.xml nach bnd.bnd
- [ ] 3. Entferne `<![CDATA[` und `]]>` Wrapper
- [ ] 4. Entferne `<configuration>` Block aus pom.xml
- [ ] 5. Build testen: `mvn clean install`
- [ ] 6. MANIFEST.MF prüfen
- [ ] 7. Bundle in OSGi testen

## 📚 Weiterführende Ressourcen

### Offizielle BND Dokumentation:
- https://bnd.bndtools.org/
- https://bnd.bndtools.org/instructions/

### BND Annotations:
- https://bnd.bndtools.org/chapters/230-manifest-annotations.html

### Best Practices:
- https://bnd.bndtools.org/chapters/325-working-with-project.html

## 🎯 Zusammenfassung

**Ihre Wahl:**

| Aspekt | Inline pom.xml | Separate bnd.bnd |
|--------|----------------|------------------|
| **Einfachheit** | ⭐⭐⭐ | ⭐⭐ |
| **Wartbarkeit** | ⭐⭐ | ⭐⭐⭐⭐⭐ |
| **IDE-Support** | ⭐⭐ | ⭐⭐⭐⭐⭐ |
| **Separation** | ⭐ | ⭐⭐⭐⭐⭐ |
| **Wiederverwendbar** | ⭐ | ⭐⭐⭐⭐⭐ |

**Empfehlung für Ihr Projekt:**
→ **Separate bnd.bnd Dateien** für bessere Wartbarkeit! ✅

**Status: Ready to use!** 🚀
